# Guía de Despliegue - MadNightsNews

Este documento detalla los pasos necesarios para reproducir el despliegue de la aplicación web **MadNightsNews** en un entorno de producción/prácticas sobre Ubuntu Server, así como el procedimiento controlado para revertir a una versión anterior utilizando el control de versiones del proyecto.

---

## 1. Información General y Acceso

* **Aplicación:** MadNightsNews (Gestión y cartelera de eventos culturales y ocio nocturno).
* **URL Principal de Acceso:** `http://madnights.test:8080/`
  *(Nota: De forma alternativa, es posible alcanzar el servidor mediante su dirección IP directa en red local, aunque el enrutamiento del host virtual requiere la resolución del dominio `madnights.test`).*
* **Puerto HTTP:** `8080`
* **Directorio de Despliegue (Host Virtual):** `/opt/tomcat/sitios/madnights`

---

## 2. Versiones del Entorno Utilizadas

Para garantizar la compatibilidad de las APIs de Jakarta EE / Servlets y los controladores JDBC, el despliegue se ha validado sobre las siguientes versiones:

* **Sistema Operativo:** Ubuntu 24.04 LTS
* **Entorno de Ejecución Java:** OpenJDK 25 (gestionado mediante SDKMAN)
* **Servidor de Aplicaciones:** Apache Tomcat 11
* **Sistema Gestor de Base de Datos:** MariaDB Server 10.11 / 11.x (Puerto `3306`)
* **Driver JDBC:** `mariadb-java-client` (con soporte dinámico interno para MySQL)

---

## 3. Pasos de Configuración y Despliegue

### Paso 1: Preparación de la Base de Datos (MariaDB)
1. Acceder a la consola de MariaDB con permisos de administración:
   ```bash
   sudo mariadb -u root -p
   ```
2. Crear la base de datos del proyecto y el usuario específico de la aplicación (evitando el uso de `root` en el código):
   ```sql
   CREATE DATABASE IF NOT EXISTS madnights_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'madnights_app'@'localhost' IDENTIFIED BY '<CONTRASEÑA_SEGURA>';
   GRANT SELECT, INSERT, UPDATE, DELETE ON madnights_db.* TO 'madnights_app'@'localhost';
   FLUSH PRIVILEGES;
   EXIT;
   ```
3. Importar la estructura de tablas y los datos iniciales desde el script SQL proporcionado:
   ```bash
   sudo mariadb -u root -p madnights_db < /ruta/al/proyecto/sql/schema_y_datos.sql
   ```

### Paso 2: Configuración de Conexión en la Aplicación
Antes de empaquetar el proyecto, verificar en `src/main/java/com/madnights/db/DatabaseConnection.java` que la variable de entorno apunta al motor de base de datos activo y contiene las credenciales creadas:
```java
private static final String DEFAULT_DB = "mariadb";
// URL configurada: jdbc:mariadb://localhost:3306/madnights_db?useSSL=false&serverTimezone=UTC
```

### Paso 3: Creación del Host Virtual en Apache Tomcat
1. Realizar una copia de seguridad de la configuración original de Tomcat:
   ```bash
   sudo cp /opt/tomcat/conf/server.xml /opt/tomcat/conf/server.xml.bak
   ```
2. Crear el directorio específico para el sitio y asignar permisos al usuario que ejecuta Tomcat:
   ```bash
   sudo mkdir -p /opt/tomcat/sitios/madnights
   sudo chown -R tomcat:tomcat /opt/tomcat/sitios/madnights
   ```
3. Editar `/opt/tomcat/conf/server.xml` y añadir el siguiente bloque `<Host>` dentro de `<Engine name="Catalina" defaultHost="localhost">`:
   ```xml
   <Host name="madnights.test" appBase="sitios/madnights"
         unpackWARs="true" autoDeploy="true">
       <Valve className="org.apache.catalina.valves.AccessLogValve" directory="logs"
              prefix="madnights_access_log" suffix=".txt"
              pattern="%h %l %u %t &quot;%r&quot; %s %b" />
   </Host>
   ```

### Paso 4: Resolución de Nombres (Servidor y Clientes)
Añadir el mapeo del dominio virtual en el archivo `hosts` tanto del servidor Ubuntu (`/etc/hosts`) como de los equipos clientes de la red (`C:\Windows\System32\drivers\etc\hosts` en Windows o `/etc/hosts` en Linux):
```text
<IP_DEL_SERVIDOR_UBUNTU>   madnights.test
```
*(En el propio servidor Ubuntu se puede apuntar a `127.0.0.1 madnights.test`).*

### Paso 5: Empaquetado y Despliegue del Archivo WAR
1. Generar el artefacto `.war` desde el proyecto (mediante Maven `mvn clean package` o desde el IDE) asegurando que se empaqueta con el nombre **`ROOT.war`** para responder en la raíz del dominio (`/`).
2. Copiar el archivo al directorio `appBase` del host virtual:
   ```bash
   sudo cp target/ROOT.war /opt/tomcat/sitios/madnights/ROOT.war
   sudo chown tomcat:tomcat /opt/tomcat/sitios/madnights/ROOT.war
   ```
3. Reiniciar Tomcat mediante sus scripts de control y verificar el despliegue en los logs:
   ```bash
   sudo /opt/tomcat/bin/shutdown.sh
   sudo /opt/tomcat/bin/startup.sh
   tail -n 30 /opt/tomcat/logs/catalina.out
   ```

---

## 4. Recuperación de una Versión Anterior (Rollback)

Dado que el código fuente íntegro y el historial de versiones se gestionan mediante **Git y GitHub**, y las configuraciones del servidor cuentan con respaldo previo, el procedimiento para revertir un despliegue defectuoso sin perder los datos almacenados en MariaDB es el siguiente:

1. **Detener Tomcat de forma controlada:**
   ```bash
   sudo /opt/tomcat/bin/shutdown.sh
   ```
2. **Restaurar el código fuente a la versión estable anterior mediante Git:**
   En el directorio local del repositorio, localizar el *commit* o etiqueta (*tag*) estable anterior y revertir o hacer *checkout* a dicha versión:
   ```bash
   git log --oneline -n 5
   git checkout <ID_COMMIT_ESTABLE>
   ```
   *(Si el fallo se debió a un cambio en el servidor, restaurar también la configuración de Tomcat: `sudo cp /opt/tomcat/conf/server.xml.bak /opt/tomcat/conf/server.xml`).*
3. **Recompilar y limpiar el despliegue fallido:**
   Generar nuevamente el archivo `ROOT.war` a partir de la versión estable recuperada. Eliminar los archivos del despliegue anterior en Tomcat (incluyendo la caché de trabajo):
   ```bash
   sudo rm -rf /opt/tomcat/sitios/madnights/ROOT /opt/tomcat/sitios/madnights/ROOT.war
   sudo rm -rf /opt/tomcat/work/Catalina/madnights.test/
   ```
4. **Desplegar el WAR recuperado y arrancar el servicio:**
   ```bash
   sudo cp target/ROOT.war /opt/tomcat/sitios/madnights/ROOT.war
   sudo chown tomcat:tomcat /opt/tomcat/sitios/madnights/ROOT.war
   sudo /opt/tomcat/bin/startup.sh
   ```
5. **Comprobación:** Acceder a `http://madnights.test:8080/` y verificar que la aplicación vuelve a estar operativa y conserva íntegros los registros previos de MariaDB.

---

## 5. Limitaciones Conocidas

* **Resolución DNS manual:** Al utilizar un dominio local ficticio (`.test`), cada equipo cliente nuevo que desee acceder a la aplicación desde la red local requiere configurar manualmente su archivo `hosts` apuntando a la IP del servidor.
* **Tráfico sin cifrar (HTTP):** El servicio opera únicamente a través del conector HTTP estándar de Tomcat en el puerto `8080`; no dispone de certificados SSL/TLS configurados para HTTPS.
* **Gestión manual del servicio Tomcat:** En el entorno actual, Apache Tomcat no está registrado como demonio de `systemd`, por lo que ante un reinicio completo del servidor Ubuntu es necesario arrancar manualmente el servicio ejecutando `/opt/tomcat/bin/startup.sh`.
* **Cambio de motor de base de datos en tiempo de compilación:** Aunque `DatabaseConnection` soporta tanto MariaDB como MySQL, la selección del motor (`DEFAULT_DB`) está definida como constante en código Java, lo que exige recompilar y redesplegar el archivo `.war` si se desea conmutar de gestor de base de datos.